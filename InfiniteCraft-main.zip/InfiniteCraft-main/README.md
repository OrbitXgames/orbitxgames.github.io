# InfiniteCraft
This may work or maybe it doesn't.
All credits go to Neal.fun
